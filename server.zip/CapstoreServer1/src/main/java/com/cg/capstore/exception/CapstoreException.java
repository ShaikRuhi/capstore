package com.cg.capstore.exception;

public class CapstoreException extends Exception {

	public CapstoreException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CapstoreException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
